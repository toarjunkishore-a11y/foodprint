    # FoodPrint — Hackathon Prototype

FoodPrint is a prototype that estimates the carbon footprint of meals. This repo contains a Next.js + TypeScript project scaffold optimized for a 3-minute hackathon demo.

## Quick start

1. Install dependencies:

```bash
npm install
```

2. Add environment variables in `.env.local`:

```
NEXT_PUBLIC_FIREBASE_API_KEY=...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=...
NEXT_PUBLIC_FIREBASE_PROJECT_ID=...
NEXT_PUBLIC_CLIMATIQ_API_KEY=...
NEXT_PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXX
```

3. Run dev server:

```bash
npm run dev
```

## What's included
- Firebase auth scaffold
- Proxy API route for Climatiq
- OpenFoodFacts lookup
- Meal builder, dashboard, accessibility & analytics snippet

## Demo notes
Seed sample data in `pages/index.tsx` if you want offline reliability during the presentation.
