import React, { useEffect, useState } from 'react'
import { auth } from '../src/firebase'
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from 'firebase/auth'
import Button from '@mui/material/Button'

export default function Auth({ onUser }: { onUser: (u: any) => void }) {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u)
      onUser(u)
    })
    return () => unsub()
  }, [onUser])

  const login = async () => {
    try {
      const provider = new GoogleAuthProvider()
      await signInWithPopup(auth, provider)
    } catch (e) {
      alert('Login failed')
      console.error(e)
    }
  }

  const logout = async () => {
    await signOut(auth)
  }

  return (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      {user ? (
        <>
          <img src={user.photoURL || '/avatar.png'} alt="avatar" width={36} height={36} style={{borderRadius: 18}} />
          <div>
            <div style={{ fontWeight: 700 }}>{user.displayName}</div>
            <Button variant="outlined" size="small" onClick={logout}>Sign out</Button>
          </div>
        </>
      ) : (
        <Button variant="contained" onClick={login}>Sign in with Google</Button>
      )}
    </div>
  )
}
