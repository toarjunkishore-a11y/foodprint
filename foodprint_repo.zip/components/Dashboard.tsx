import React from 'react'
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts'

export default function Dashboard({ items }: { items: any[] }) {
  const total = items.reduce((s, i) => s + (i.co2e || 0), 0)
  const data = items.slice(0, 8).map(i => ({ name: i.name, co2: Number((i.co2e || 0).toFixed(2)) }))

  return (
    <section aria-label="Dashboard">
      <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
        <div style={{ flex: 1 }}>
          <h3>Your meal footprint</h3>
          <div style={{ fontSize: 28, fontWeight: 700 }}>{total.toFixed(2)} kgCO₂e</div>
          <p>Average across samples.</p>
        </div>
        <div style={{ width: 300, height: 150 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <XAxis dataKey="name" hide />
              <YAxis />
              <Tooltip />
              <Bar dataKey="co2" fill="#2b6cb0" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={{ marginTop: 12 }}>
        <h4>Suggestions</h4>
        <ul>
          <li>Swap beef with beans — save ~6 kgCO₂e per 200 g</li>
          <li>Prefer seasonal, local produce — use the AR menu demo to see alternatives</li>
        </ul>
      </div>
    </section>
  )
}
