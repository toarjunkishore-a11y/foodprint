import React, { useState } from 'react'
import axios from 'axios'
import { useForm } from 'react-hook-form'
import { motion } from 'framer-motion'

type FormData = { ingredient: string; quantityGrams: number }

export default function MealBuilder({ onAdd }: { onAdd: (m: any) => void }) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({ defaultValues: { quantityGrams: 100 } })
  const [searching, setSearching] = useState(false)
  const [history, setHistory] = useState<any[]>([])

  const onSubmit = async (data: FormData) => {
    try {
      setSearching(true)
      const name = data.ingredient
      const quantityKg = data.quantityGrams / 1000
      const est = await axios.post('/api/estimate', { foodName: name, quantityKg })
      const footprint = est.data.data?.co2e ?? est.data.data?.co2e || (2 * quantityKg)

      const mealItem = {
        id: Date.now(),
        name,
        grams: data.quantityGrams,
        kg: quantityKg,
        co2e: footprint,
        timestamp: new Date().toISOString(),
      }

      setHistory((s) => [mealItem, ...s].slice(0, 10))
      onAdd(mealItem)
    } catch (e) {
      console.error(e)
      alert('Failed to estimate — check console')
    } finally {
      setSearching(false)
    }
  }

  return (
    <div style={{ padding: 12 }}>
      <form onSubmit={handleSubmit(onSubmit)} aria-label="Add ingredient form">
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input aria-label="ingredient" placeholder="e.g. beef, rice, avocado" {...register('ingredient', { required: true, minLength: 1 })} />
          <input aria-label="quantity" type="number" {...register('quantityGrams', { valueAsNumber: true, min: 1 })} />
          <button type="submit" disabled={isSubmitting || searching}>Estimate</button>
        </div>
        {errors.ingredient && <div role="alert">Please provide an ingredient</div>}
      </form>

      <div style={{ marginTop: 16 }}>
        <h4>Recent estimates</h4>
        {history.length === 0 ? <p>No items yet</p> : (
          history.map(h => (
            <motion.div key={h.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} style={{ padding: 8, borderBottom: '1px solid #eee' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div>{h.name} — {h.grams} g</div>
                <div style={{ fontWeight: 700 }}>{(h.co2e).toFixed(2)} kgCO₂e</div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  )
}
