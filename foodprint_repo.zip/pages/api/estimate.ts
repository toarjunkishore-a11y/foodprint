import type { NextApiRequest, NextApiResponse } from 'next'
import axios from 'axios'

const CLIMATIQ_KEY = process.env.NEXT_PUBLIC_CLIMATIQ_API_KEY || ''

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { foodName, quantityKg } = req.body
    if (!foodName || typeof quantityKg !== 'number') {
      return res.status(400).json({ error: 'Missing foodName or quantityKg' })
    }

    if (!CLIMATIQ_KEY) {
      // Mock response for demo
      const mock = { co2e: 2.5 * quantityKg, unit: 'kgCO2e' }
      return res.status(200).json({ data: mock })
    }

    const search = await axios.post(
      'https://beta3.api.climatiq.io/estimate',
      {
        emission_factor: {
          activity_id: 'food.kg',
          emission_factor: 1
        },
        parameters: { quantity: quantityKg }
      },
      { headers: { Authorization: `Bearer ${CLIMATIQ_KEY}` } }
    )

    return res.status(200).json({ data: search.data })
  } catch (err: any) {
    console.error(err?.response?.data || err.message || err)
    return res.status(500).json({ error: 'Estimation failed' })
  }
}
