import React, { useState } from 'react'
import Auth from '../components/Auth'
import MealBuilder from '../components/MealBuilder'
import Dashboard from '../components/Dashboard'

const SAMPLE = [
  { id: 1, name: 'Beef (200g)', grams: 200, co2e: 12.4, timestamp: '2025-09-01T12:00:00Z' },
  { id: 2, name: 'Rice (200g)', grams: 200, co2e: 0.6, timestamp: '2025-09-04T10:00:00Z' },
  { id: 3, name: 'Avocado (50g)', grams: 50, co2e: 0.2, timestamp: '2025-09-03T10:00:00Z' }
]

export default function Home() {
  const [user, setUser] = useState<any>(null)
  const [items, setItems] = useState<any[]>(SAMPLE)

  const addItem = (m: any) => setItems((s) => [m, ...s].slice(0, 50))

  return (
    <main style={{ padding: 20, maxWidth: 980, margin: '0 auto' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>FoodPrint</h1>
        <Auth onUser={setUser} />
      </header>

      <section style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '1fr 400px', gap: 20 }}>
        <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 6px 20px rgba(0,0,0,0.06)', padding: 12 }}>
          <h2>Estimate a meal</h2>
          <MealBuilder onAdd={addItem} />
        </div>

        <aside style={{ background: '#fff', borderRadius: 12, padding: 12 }}>
          <h3>Live Dashboard</h3>
          <Dashboard items={items} />
        </aside>
      </section>

      <footer style={{ marginTop: 32 }}>
        <small>Demo-ready prototype — FoodPrint ©</small>
      </footer>
    </main>
  )
}
